var mainwindow_8cpp =
[
    [ "dane", "mainwindow_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6", null ]
];