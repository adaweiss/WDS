var trasa_8hh =
[
    [ "Trasa", "class_trasa.html", "class_trasa" ],
    [ "D", "trasa_8hh.html#af316c33cc298530f245e8b55330e86b5", null ],
    [ "PAINT_PRESCALER", "trasa_8hh.html#a54aee68ea5d21c1ff7999b13f3fb58e2", null ],
    [ "R", "trasa_8hh.html#a5c71a5e59a53413cd6c270266d63b031", null ],
    [ "TIME_PRESCALER_SEC", "trasa_8hh.html#a84f58a271e6d602a7f75debc82eb7951", null ]
];