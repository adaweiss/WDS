var searchData=
[
  ['r',['R',['../trasa_8hh.html#a5c71a5e59a53413cd6c270266d63b031',1,'trasa.hh']]],
  ['r_5fkola',['R_KOLA',['../czujniki_8cpp.html#aa1ea75aca21ebd2b34b77f0c66343341',1,'czujniki.cpp']]]
];
