var searchData=
[
  ['validrange',['validRange',['../class_q_c_p_range.html#ab38bd4841c77c7bb86c9eea0f142dcc0',1,'QCPRange::validRange(double lower, double upper)'],['../class_q_c_p_range.html#a801b964752eaad6219be9d8a651ec2b3',1,'QCPRange::validRange(const QCPRange &amp;range)']]],
  ['viewport',['viewport',['../class_q_custom_plot.html#a953ecdbc28018e7e84cb6213ad3d88c2',1,'QCustomPlot']]]
];
