var searchData=
[
  ['paintevent',['paintEvent',['../class_czujniki.html#a3bb54c1cca3ba30b92143129f38637e9',1,'Czujniki::paintEvent()'],['../class_trasa.html#a369eb849159b2673663784bab2655964',1,'Trasa::paintEvent()']]],
  ['plot',['plot',['../class_wykres.html#a5733ec2d1bef2b52cb8fe1022336d14d',1,'Wykres']]]
];
