var searchData=
[
  ['scale',['scale',['../class_trasa.html#a4bc5fca0e6c9e2d18cfbd7b0ee0a6c47',1,'Trasa']]],
  ['start_5fflag',['start_flag',['../class_main_window.html#a2d263bf60dff7452a4fabba4f1ef47dc',1,'MainWindow']]]
];
