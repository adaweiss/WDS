var searchData=
[
  ['bufor_5flength',['BUFOR_LENGTH',['../data_8hh.html#a21b07b7bdba051b0e5e6102011204b3b',1,'data.hh']]]
];
