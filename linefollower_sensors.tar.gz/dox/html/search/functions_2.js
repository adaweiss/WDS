var searchData=
[
  ['data',['Data',['../data_8hh.html#af11f741cb7f587e2e495452a8905a22a',1,'data.cpp']]],
  ['desk',['desk',['../class_main_window.html#ad000e48bacc14dccf59231bb30b046ac',1,'MainWindow']]]
];
