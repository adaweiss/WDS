var searchData=
[
  ['wykres',['Wykres',['../class_wykres.html',1,'']]]
];
