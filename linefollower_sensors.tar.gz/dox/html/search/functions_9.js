var searchData=
[
  ['refresh',['refresh',['../class_main_window.html#ab27297114529e4c16d6d8d7a54927a0e',1,'MainWindow']]]
];
