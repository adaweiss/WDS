var searchData=
[
  ['enc1',['enc1',['../data_8hh.html#a3d947897026adac2eb1b5366c9fe357d',1,'data.hh']]],
  ['enc2',['enc2',['../data_8hh.html#a69f1ba0751afcb88bf83a5bab2118f5e',1,'data.hh']]]
];
