var searchData=
[
  ['gradientpreset',['GradientPreset',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072',1,'QCPColorGradient']]]
];
