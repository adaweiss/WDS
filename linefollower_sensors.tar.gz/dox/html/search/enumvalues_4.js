var searchData=
[
  ['gpcandy',['gpCandy',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a9e72663bf6b94b65945f7843f24e0721',1,'QCPColorGradient']]],
  ['gpcold',['gpCold',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072aec8c001f62c0d5cb853db5fd85309557',1,'QCPColorGradient']]],
  ['gpgeography',['gpGeography',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a382f0b07cec1a59d8a533438aea815d2',1,'QCPColorGradient']]],
  ['gpgrayscale',['gpGrayscale',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072add11ae369a86f3b1b6205ec72e5021fb',1,'QCPColorGradient']]],
  ['gphot',['gpHot',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a4f42e534cf6cff5a29a5388094d099b5',1,'QCPColorGradient']]],
  ['gphues',['gpHues',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a30efe58407acfb67939032f70213a130',1,'QCPColorGradient']]],
  ['gpion',['gpIon',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a4297f4f9e212a819cd65e8e34567182b',1,'QCPColorGradient']]],
  ['gpjet',['gpJet',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a5f8a9e67b64c17ddfe4f069fe2b9fb02',1,'QCPColorGradient']]],
  ['gpnight',['gpNight',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072a1bb89351b6def7d220973443fe059c62',1,'QCPColorGradient']]],
  ['gppolar',['gpPolar',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072ab7414ce4e36dc3e82e0132a7f0f41b52',1,'QCPColorGradient']]],
  ['gpspectrum',['gpSpectrum',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072ad63adc100ef46f6b4a8a6deacec4642f',1,'QCPColorGradient']]],
  ['gpthermal',['gpThermal',['../class_q_c_p_color_gradient.html#aed6569828fee337023670272910c9072af1676b129f9f458ace453f280c731cf7',1,'QCPColorGradient']]]
];
