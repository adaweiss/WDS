var searchData=
[
  ['yaxis',['yAxis',['../class_q_custom_plot.html#af6fea5679725b152c14facd920b19367',1,'QCustomPlot']]],
  ['yaxis2',['yAxis2',['../class_q_custom_plot.html#af13fdc5bce7d0fabd640f13ba805c0b7',1,'QCustomPlot']]]
];
