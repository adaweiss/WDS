var searchData=
[
  ['scale',['scale',['../class_trasa.html#a4bc5fca0e6c9e2d18cfbd7b0ee0a6c47',1,'Trasa']]],
  ['set_5fscale',['set_scale',['../class_trasa.html#abd50f0fb27911e6f85b2654de5ec68b5',1,'Trasa']]],
  ['setdesk',['setDesk',['../class_main_window.html#a78eb93451b676752f966dc2f45c7a2a1',1,'MainWindow']]],
  ['showtext',['showText',['../class_info.html#a4e4b10d7c315720a5d99dbca038f64e7',1,'Info']]],
  ['start_5fflag',['start_flag',['../class_main_window.html#a2d263bf60dff7452a4fabba4f1ef47dc',1,'MainWindow']]]
];
