var searchData=
[
  ['timeval',['timeval',['../data_8hh.html#aa169e0d4f310b9042eaed9c52b2c807d',1,'data.hh']]],
  ['trasa',['Trasa',['../class_trasa.html#a00694745a2bbcf0b6c449450073406ff',1,'Trasa']]]
];
