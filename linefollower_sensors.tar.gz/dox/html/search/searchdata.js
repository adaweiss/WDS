var indexSectionsWithContent =
{
  0: "abcdefgimopqrstuw~",
  1: "cimtw",
  2: "u",
  3: "cdimtw",
  4: "acdefimoprstw~",
  5: "cdiqstu",
  6: "bdgiprt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros"
};

