var searchData=
[
  ['time',['time',['../data_8hh.html#a47dc728f262872d5f1d2bbdc7538e118',1,'data.hh']]],
  ['timer',['timer',['../class_main_window.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]]
];
