var searchData=
[
  ['time',['time',['../data_8hh.html#a47dc728f262872d5f1d2bbdc7538e118',1,'data.hh']]],
  ['time_5fprescaler',['TIME_PRESCALER',['../data_8hh.html#a84ddc7587ef7da6fb1ae9f5c98e070ac',1,'data.hh']]],
  ['time_5fprescaler_5fsec',['TIME_PRESCALER_SEC',['../trasa_8hh.html#a84f58a271e6d602a7f75debc82eb7951',1,'trasa.hh']]],
  ['timer',['timer',['../class_main_window.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]],
  ['timer_5fperiod',['TIMER_PERIOD',['../mainwindow_8h.html#ad888acf7c13a4bedd6541ceb5cf9bf6d',1,'mainwindow.h']]],
  ['timeval',['timeval',['../data_8hh.html#aa169e0d4f310b9042eaed9c52b2c807d',1,'data.hh']]],
  ['trasa',['Trasa',['../class_trasa.html',1,'Trasa'],['../class_trasa.html#a00694745a2bbcf0b6c449450073406ff',1,'Trasa::Trasa()']]],
  ['trasa_2ecpp',['trasa.cpp',['../trasa_8cpp.html',1,'']]],
  ['trasa_2ehh',['trasa.hh',['../trasa_8hh.html',1,'']]]
];
