var searchData=
[
  ['update',['update',['../class_q_c_p_layout_element.html#a929c2ec62e0e0e1d8418eaa802e2af9b',1,'QCPLayoutElement::update()'],['../class_q_c_p_layout.html#a34ab477e820537ded7bade4399c482fd',1,'QCPLayout::update()'],['../class_q_c_p_axis_rect.html#a255080a017df9083a60a321ef2ba9ed8',1,'QCPAxisRect::update()'],['../class_q_c_p_color_scale.html#ab8f6991ac88243fc582b44b183670334',1,'QCPColorScale::update()']]],
  ['updatelegendicon',['updateLegendIcon',['../class_q_c_p_color_map.html#a5d8158b62d55fcfeaabcb68ce0083e87',1,'QCPColorMap']]],
  ['updateposition',['updatePosition',['../class_q_c_p_item_tracer.html#a5b90296109e36384aedbc8908a670413',1,'QCPItemTracer']]]
];
