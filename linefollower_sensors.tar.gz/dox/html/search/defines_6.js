var searchData=
[
  ['time_5fprescaler',['TIME_PRESCALER',['../data_8hh.html#a84ddc7587ef7da6fb1ae9f5c98e070ac',1,'data.hh']]],
  ['time_5fprescaler_5fsec',['TIME_PRESCALER_SEC',['../trasa_8hh.html#a84f58a271e6d602a7f75debc82eb7951',1,'trasa.hh']]],
  ['timer_5fperiod',['TIMER_PERIOD',['../mainwindow_8h.html#ad888acf7c13a4bedd6541ceb5cf9bf6d',1,'mainwindow.h']]]
];
