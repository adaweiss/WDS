var searchData=
[
  ['set_5fscale',['set_scale',['../class_trasa.html#abd50f0fb27911e6f85b2654de5ec68b5',1,'Trasa']]],
  ['setdesk',['setDesk',['../class_main_window.html#a78eb93451b676752f966dc2f45c7a2a1',1,'MainWindow']]],
  ['showtext',['showText',['../class_info.html#a4e4b10d7c315720a5d99dbca038f64e7',1,'Info']]]
];
