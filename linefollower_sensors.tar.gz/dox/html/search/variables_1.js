var searchData=
[
  ['dane',['dane',['../czujniki_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6',1,'dane():&#160;main.cpp'],['../info_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6',1,'dane():&#160;main.cpp'],['../main_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6',1,'dane():&#160;main.cpp'],['../mainwindow_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6',1,'dane():&#160;main.cpp'],['../trasa_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6',1,'dane():&#160;main.cpp']]],
  ['desk_5fportu',['desk_portu',['../class_main_window.html#a227a342bafd8ac62990190f15bdabdb3',1,'MainWindow']]]
];
