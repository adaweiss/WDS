var transparam_8hh =
[
    [ "Type4BaudRate", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288f", [
      [ "B_0", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa47289a31fc82b611270f1f065dd29374", null ],
      [ "B_50", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa9401cafe870d964773dd29c41dd9725e", null ],
      [ "B_75", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa677772bcffc885d68682ea2e57a96369", null ],
      [ "B_110", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fad6c9bbc6b9d05dfce96cc12c70190b53", null ],
      [ "B_134", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa6741f347183b1cc2b8e40eb83a2555c2", null ],
      [ "B_150", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa0005d784524361a5cdebe194bc9a7e95", null ],
      [ "B_200", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa510049aa4782215852025c13fd141efc", null ],
      [ "B_300", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fabd0f221fb68bcb918831d4eb9d5e2e53", null ],
      [ "B_600", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288faad53e0d4baaafd1d93514a739f25d89e", null ],
      [ "B_1200", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fae3f5102fc8661e8b758980d442c11b8e", null ],
      [ "B_1800", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa3a49add2b8f9e87593226dc34583f5d0", null ],
      [ "B_2400", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa2898cf1c1e6cdb0b7fc6fff5c142c4ba", null ],
      [ "B_4800", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa27a92d1ac239b3d44e3a8fc27b6b039f", null ],
      [ "B_9600", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fae7bf4de131e0edb182e39d87d3027018", null ],
      [ "B_19200", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa4ecf44e3017ea2b99239d127250289d1", null ],
      [ "B_38400", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288faba0b508458bf2a54509bb8a20478ca93", null ],
      [ "B_57600", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa499f4f816c2ffec705d374891bc6eb51", null ],
      [ "B_115200", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fae5aff27725ed62df17a9d52c9435d0d5", null ],
      [ "B_230400", "transparam_8hh.html#aaaf70130106e45f329823bb7383b288fa9ec9266a076b069458fcabcac21f748f", null ]
    ] ],
    [ "Type4CharacterSize", "transparam_8hh.html#ad43ec836453f31ea6160c8ec311a9d90", [
      [ "CS_5", "transparam_8hh.html#ad43ec836453f31ea6160c8ec311a9d90ae8764489eb63e8cfa4e79d91e26f90a3", null ],
      [ "CS_6", "transparam_8hh.html#ad43ec836453f31ea6160c8ec311a9d90a1625f022daa414fd47e25c90eff82460", null ],
      [ "CS_7", "transparam_8hh.html#ad43ec836453f31ea6160c8ec311a9d90a83bba2f5593a571fa5bcadb504f035cd", null ],
      [ "CS_8", "transparam_8hh.html#ad43ec836453f31ea6160c8ec311a9d90aca6d77a969cda9a7d5b3764645230ca8", null ]
    ] ],
    [ "Type4Parity", "transparam_8hh.html#a8ff99acb992470a0e45a2ab0cb77b237", [
      [ "P_None", "transparam_8hh.html#a8ff99acb992470a0e45a2ab0cb77b237a34382ce4bb40c1824bcca93bc234ab6b", null ],
      [ "P_Even", "transparam_8hh.html#a8ff99acb992470a0e45a2ab0cb77b237ad9cecbcfe646fb2ce2698ba1daf23d62", null ],
      [ "P_Odd", "transparam_8hh.html#a8ff99acb992470a0e45a2ab0cb77b237ac4d5e9249b497ebae3148a6545300842", null ],
      [ "P_Mark", "transparam_8hh.html#a8ff99acb992470a0e45a2ab0cb77b237a2457874c281d6ec0f92dc6e61f79587d", null ],
      [ "P_Space", "transparam_8hh.html#a8ff99acb992470a0e45a2ab0cb77b237a016cb8ef0f82bf2ea07e6cf6c0e63882", null ]
    ] ],
    [ "SetTransParam", "transparam_8hh.html#adae5ef433c18e71af7b1a18cd4c107e6", null ]
];