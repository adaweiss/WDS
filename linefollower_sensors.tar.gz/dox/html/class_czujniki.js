var class_czujniki =
[
    [ "Czujniki", "class_czujniki.html#a1b3e6e1807e19db4bca1a7c5f86bb30d", null ],
    [ "paintEvent", "class_czujniki.html#a3bb54c1cca3ba30b92143129f38637e9", null ]
];