var odbieranie_8cpp =
[
    [ "ROZMIAR_LINII", "odbieranie_8cpp.html#ac4f92db10fea9b5bd0337dcfa87f1850", null ],
    [ "Czas_JestPozniejNiz", "odbieranie_8cpp.html#acb92bf56d0e1ea8c61397989de2972c5", null ],
    [ "RS232_Odbierz", "odbieranie_8cpp.html#a6befdeb19cdb98ce397b800b2bf28ce1", null ],
    [ "RS232_Odbierz", "odbieranie_8cpp.html#aebff1e4ab04b6e0d4e0cb0b2cb34d8c8", null ],
    [ "TestOdbioru", "odbieranie_8cpp.html#a8ba1cb8263e0f85250d2dbd1fb60e825", null ]
];