var czujniki_8cpp =
[
    [ "GDZIE", "czujniki_8cpp.html#add0847d762ca081e23c0c9d7081a8ed9", null ],
    [ "R_KOLA", "czujniki_8cpp.html#aa1ea75aca21ebd2b34b77f0c66343341", null ],
    [ "dane", "czujniki_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6", null ]
];