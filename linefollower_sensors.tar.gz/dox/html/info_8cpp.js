var info_8cpp =
[
    [ "dane", "info_8cpp.html#a2c9fa58e1df8869f91360abaae3550b6", null ]
];