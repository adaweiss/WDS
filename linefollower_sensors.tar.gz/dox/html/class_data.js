var class_data =
[
    [ "Data", "class_data.html#af11f741cb7f587e2e495452a8905a22a", null ],
    [ "addData", "class_data.html#af7b0ea61f23e7b110d93bf6e4bbd0a68", null ],
    [ "checkData", "class_data.html#ad0f1a565fb905a7ff9bf808bdbf6f032", null ],
    [ "clearData", "class_data.html#a644ad8f01a05ab5e995ebc613b2fcab9", null ],
    [ "enc1", "class_data.html#a42e5478ec68cba198ecd950483128002", null ],
    [ "enc2", "class_data.html#a923300a69b041facb7c636ae9d7d034d", null ],
    [ "foto1", "class_data.html#a0264ac1cec44285442dccd223c18e039", null ],
    [ "foto2", "class_data.html#aeff8d85deabaefaef72ff86e09966768", null ],
    [ "foto3", "class_data.html#a1a80e47f3780f3a5ed6abee32d6d3b1c", null ],
    [ "foto4", "class_data.html#ae86e0496a4ae514af5f6a7c1317d2c70", null ],
    [ "foto5", "class_data.html#a236953f28ce6485de76ecc77bd988820", null ],
    [ "foto6", "class_data.html#a73b32823192c2df6e97bc319eebd6b4c", null ],
    [ "foto7", "class_data.html#a49b89dc5597fb5c411709476833bd1e9", null ]
];