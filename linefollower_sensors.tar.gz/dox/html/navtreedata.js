var NAVTREE =
[
  [ "LINEFOLLOWER", "index.html", [
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"class_q_c_p_axis.html#a57d6ee9e9009fe88cb19db476ec70bca",
"class_q_c_p_axis_rect.html#ab49d338d1ce74b476fcead5b32cf06dc",
"class_q_c_p_color_scale.html#aa8debce1be38b54287c04d4f584394b4",
"class_q_c_p_grid.html#aa9004bc139ad3ea92629f0aaae81d83f",
"class_q_c_p_item_rect.html#af0ebba58e6bca4851c4db726691ec0d3a69fa21fde2f44036381296a6f78b4eb4",
"class_q_c_p_layout_element.html#aeafbbc1130e02eee663c5326761fc963",
"class_q_c_p_plottable_legend_item.html#ad762b07439c738660ba93e78c1d03667",
"class_q_custom_plot.html#abdfd07d4f0591d0cf967f85013fd3645",
"qcustomplot_8h.html#ae6c02a20d51ce03bc5dfd27c25a1cc6a"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';