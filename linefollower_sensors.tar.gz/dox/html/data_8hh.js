var data_8hh =
[
    [ "Data", "class_data.html", "class_data" ],
    [ "TIME_PRESCALER", "data_8hh.html#a84ddc7587ef7da6fb1ae9f5c98e070ac", null ]
];