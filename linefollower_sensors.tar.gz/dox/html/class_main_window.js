var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "info", "class_main_window.html#a78f945084286506a64269d4ee75db224", null ],
    [ "on_p_bar_enc1_valueChanged", "class_main_window.html#a30ce7289906904e93b66e3fd61c07a06", null ],
    [ "on_p_bar_enc2_valueChanged", "class_main_window.html#a03f1fada2790cf415d4e3117dc519a96", null ],
    [ "refresh", "class_main_window.html#ab27297114529e4c16d6d8d7a54927a0e", null ]
];