var struct_q_c_p_axis_painter_private_1_1_cached_label =
[
    [ "offset", "struct_q_c_p_axis_painter_private_1_1_cached_label.html#a5f502db71c92e572f1e6f44f62c59d8e", null ],
    [ "pixmap", "struct_q_c_p_axis_painter_private_1_1_cached_label.html#a461597cbd470914a9d24b64d16037a88", null ]
];